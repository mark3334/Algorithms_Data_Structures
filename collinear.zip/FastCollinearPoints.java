import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

import java.util.Comparator;

public class FastCollinearPoints {
    private int numSegments = 0;
    private LineSegment[] lineSegments;
    private Point[] points;
    private Point[] pointsCopy;

    // finds all line segments containing 4 or more points
    public FastCollinearPoints(Point[] points) {
        if (points == null) throw new IllegalArgumentException("Points array cannot be null");
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null)
                throw new IllegalArgumentException("No item in points array can be null");
        }

        // O(n^2) algorithm - should be done using mergesort but my merge sort was written to only work on pointsCopy, so I'm going to leave it
        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0)
                    throw new IllegalArgumentException("There must not be any repeated points");
            }
        }

        this.points = points.clone(); // prevents external modification of array
        this.pointsCopy = new Point[points.length];
        lineSegments = new LineSegment[points.length];

        lineSegments = new LineSegment[points.length];

        for (int i = 0; i < points.length; i++) {
            Comparator<Point> comp = points[i].slopeOrder();
            resetPointsCopy();
            // in order to stop duplicate lines being added or partial segments being added e.g. if there is a line segment
            // p->q->r->s->t there shouldn't also be line segment q -> t
            // to do this we must look at all points when considering an origin p
            // then only add the line segment if the current point is first/last in the slope order.
            int startIndex = 0; // instead of i + 1
            sort(comp, 0); // instead of sort(comp, i + 1)v
            // if (points.length - i < 3) continue;
            // pointsCopy is now sorted by the slope each point makes with points[i]
            int len = 1;
            for (int j = startIndex; j < pointsCopy.length - 1; j++) {
                if (comp.compare(pointsCopy[j], pointsCopy[j + 1]) == 0) {
                    len++;
                }
                else {
                    if (len >= 3) addSegment(j, len, i);
                    len = 1;
                }
            }

            // If the last point in sorted array is in a group of collinear points with the origin points[i]
            if (len >= 3) {
                addSegment(pointsCopy.length - 1, len, i);
            }
        }


        LineSegment[] segments = new LineSegment[numSegments];
        for (int i = 0; i < numSegments; i++) {
            segments[i] = lineSegments[i];
        }
        lineSegments = segments;
    }

    private void addSegment(int j, int len, int i) {
        // addSegment( pointsCopy[j - len + 1] - pointsCopy[j] with points[i] ) from [j - len + 1, j]
        Point[] segment = new Point[len + 1];
        for (int k = 0; k < len; k++) {
            segment[k] = pointsCopy[j - k];
        }
        segment[len] = points[i];
        // get max x/y for points
        int maxIndex = 0;
        int minIndex = 0;
        for (int k = 1; k < (len + 1); k++) {
            // if the current point is less than the point at minIndex
            if (segment[k].compareTo(segment[minIndex]) < 0) minIndex = k;
            // if the current point is greater than the point at maxIndex
            if (segment[k].compareTo(segment[maxIndex]) > 0) maxIndex = k;
        }

        // Add only if origin is the smallest or largest - Important: you must pick only one of the conditions to use
        if (segment[minIndex].compareTo(points[i]) != 0) return;

        LineSegment ls = new LineSegment(segment[minIndex], segment[maxIndex]);
        if (numSegments == lineSegments.length) {
            expandLineSegments(2 * lineSegments.length);
        }
        lineSegments[numSegments] = ls;
        numSegments++;
    }

    private void expandLineSegments(int newCapacity) {
        LineSegment[] newLineSegments = new LineSegment[newCapacity];
        for (int i = 0; i < lineSegments.length; i++) {
            newLineSegments[i] = lineSegments[i];
        }
        lineSegments = newLineSegments;
    }

    private void resetPointsCopy() {
        for (int j = 0; j < points.length; j++) {
            pointsCopy[j] = points[j];
        }
    }

    private void sort(Comparator<Point> slopeOrder, int i) {
        mergeSort(slopeOrder, i, points.length);
    }

    private void mergeSort(Comparator<Point> slopeOrder, int start, int end) {
        if (end - start <= 1) return;
        int middle = start + ((end - start) / 2);
        mergeSort(slopeOrder, start, middle);
        mergeSort(slopeOrder, middle, end);
        merge(slopeOrder, start, end);
    }

    private void merge(Comparator<Point> slopeOrder, int start, int end) {
        int middle = start + ((end - start) / 2);
        // Given that the array from [start, middle) and from [middle, end) are sorted merge them into one
        // length of this sub array is end - start
        int n1 = middle - start;
        int n2 = end - middle;
        Point[] L = new Point[n1];
        Point[] R = new Point[n2];
        for (int i = 0; i < n1; ++i)
            L[i] = pointsCopy[start + i];
        for (int j = 0; j < n2; ++j)
            R[j] = pointsCopy[middle + j];

        int i = 0, j = 0;
        int k = start;
        while (i < n1 && j < n2) {
            if (slopeOrder.compare(L[i], R[j]) < 0) {
                pointsCopy[k] = L[i];
                i++;
            }
            else {
                pointsCopy[k] = R[j];
                j++;
            }
            k++;
        }
        // for (; i < n1; i++, k++) {
        //     pointsCopy[k] = L[i];
        // }
        while (i < n1) {
            pointsCopy[k] = L[i];
            i++;
            k++;
        }


        while (j < n2) {
            pointsCopy[k] = R[j];
            j++;
            k++;
        }


    }

    public int numberOfSegments() {
        return numSegments;
    }

    public LineSegment[] segments() {
        return lineSegments.clone();
    }

    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        FastCollinearPoints collinear = new FastCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();


        // Point p1 = new Point(0, 0);
        // Point p2 = new Point(1, 1);
        // Point p3 = new Point(2, 2);
        // Point p4 = new Point(3, 3);
        // Point p5 = new Point(4, 8);
        //
        // // Pass the points to FastCollinearPoints
        // Point[] points = { p1, p2, p3, p4, p5 };
        // FastCollinearPoints collinearPoints = new FastCollinearPoints(points);
        // collinearPoints.sort(p1.slopeOrder(), 0);
        // // Print the line segments
        // System.out.println("Number of line segments: " + collinearPoints.numberOfSegments());
        // for (LineSegment ls : collinearPoints.segments()) {
        //     System.out.println(ls);
        // }

    }
}