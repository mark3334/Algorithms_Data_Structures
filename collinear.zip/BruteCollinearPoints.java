import edu.princeton.cs.algs4.In;
import edu.princeton.cs.algs4.StdDraw;
import edu.princeton.cs.algs4.StdOut;

public class BruteCollinearPoints {
    private int numSegments = 0;
    private LineSegment[] lineSegments;

    public BruteCollinearPoints(Point[] points) {
        // Get every choice of 4 points from the array and check if they lie on the same line
        // If 4 points appear on a line segment in the order p→q→r→s then return line segment p→s xor s→p
        // points.length
        if (points == null) throw new IllegalArgumentException("Points array cannot be null");
        for (int i = 0; i < points.length; i++) {
            if (points[i] == null)
                throw new IllegalArgumentException("No item in points array can be null");
        }
        for (int i = 0; i < points.length - 1; i++) {
            for (int j = i + 1; j < points.length; j++) {
                if (points[i].compareTo(points[j]) == 0)
                    throw new IllegalArgumentException("There must not be any repeated points");
            }
        }
        lineSegments = new LineSegment[points.length];
        for (int i = 0; i < points.length - 3; i++) {
            for (int j = i + 1; j < points.length - 2; j++) {
                for (int k = j + 1; k < points.length - 1; k++) {
                    for (int m = k + 1; m < points.length; m++) {
                        if (colinearpoints(points[i], points[j], points[k], points[m])) {
                            addLineSegment(points[i], points[j], points[k], points[m]);
                        }
                    }
                }
            }
        }
        LineSegment[] segments = new LineSegment[numSegments];
        for (int i = 0; i < numSegments; i++) {
            segments[i] = lineSegments[i];
        }
        lineSegments = segments;
    }

    private boolean colinearpoints(Point p1, Point p2, Point p3, Point p4) {
        return p1.slopeTo(p2) == p2.slopeTo(p3) && p2.slopeTo(p3) == p3.slopeTo(p4);
        // if (p1.slopeTo(p2) != p2.slopeTo(p3)) return false;
        // if (p2.slopeTo(p3) != p3.slopeTo(p4)) return false;
        // return true;
    }

    private void addLineSegment(Point p1, Point p2, Point p3, Point p4) {
        Point[] points = { p1, p2, p3, p4 };
        sortPoints(points);
        LineSegment ls = new LineSegment(points[0], points[points.length - 1]);
        if (numSegments == lineSegments.length) {
            expandLineSegments(2 * lineSegments.length);
        }
        lineSegments[numSegments] = ls;
        numSegments++;
    }

    private void sortPoints(Point[] points) {
        // selection sort
        for (int i = 0; i < points.length - 1; i++) {
            Point minPoint = points[i];
            int minIndex = i;
            for (int j = i + 1; j < points.length; j++) {
                if (minPoint.compareTo(points[j]) > 0) {
                    minPoint = points[j];
                    minIndex = j;
                }
            }
            // swap i, minIndex
            Point temp = points[i];
            points[i] = points[minIndex];
            points[minIndex] = temp;
        }
    }

    private void expandLineSegments(int newCapacity) {
        LineSegment[] newLineSegments = new LineSegment[newCapacity];
        for (int i = 0; i < lineSegments.length; i++) {
            newLineSegments[i] = lineSegments[i];
        }
        lineSegments = newLineSegments;
    }

    public int numberOfSegments() {
        return numSegments;
    }      // the number of line segments

    public LineSegment[] segments() {
        return lineSegments.clone();
    }

    public static void main(String[] args) {
        // read the n points from a file
        In in = new In(args[0]);
        int n = in.readInt();
        Point[] points = new Point[n];
        for (int i = 0; i < n; i++) {
            int x = in.readInt();
            int y = in.readInt();
            points[i] = new Point(x, y);
        }

        // draw the points
        StdDraw.enableDoubleBuffering();
        StdDraw.setXscale(0, 32768);
        StdDraw.setYscale(0, 32768);
        for (Point p : points) {
            p.draw();
        }
        StdDraw.show();

        // print and draw the line segments
        BruteCollinearPoints collinear = new BruteCollinearPoints(points);
        for (LineSegment segment : collinear.segments()) {
            StdOut.println(segment);
            segment.draw();
        }
        StdDraw.show();

        // Point p1 = new Point(0, 0);
        // Point p2 = new Point(1, 1);
        // Point p3 = new Point(2, 2);
        // Point p4 = new Point(3, 3);
        // Point p5 = new Point(4, 8);

        // // Pass the points to BruteCollinearPoints
        // Point[] points = { p1, p2, p3, p4, p5 };
        // BruteCollinearPoints collinearPoints = new BruteCollinearPoints(points);
        //
        // // Print the line segments
        // System.out.println("Number of line segments: " + collinearPoints.numberOfSegments());
        // for (LineSegment ls : collinearPoints.segments()) {
        //     System.out.println(ls);
        // }
    }
}
